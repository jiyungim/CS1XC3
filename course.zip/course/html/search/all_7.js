var searchData=
[
  ['student_2ec',['student.c',['../student_8c.html',1,'']]]
];
